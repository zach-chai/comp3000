Author: Zachary Chai
Student Number: 100893114
Course: COMP 3000

All the shell scripts end in .sh
ALl the files created by the script command are suffixed with '_test.txt' for part 2
For Question 4: I included a books.txt with 5 books
For Question 3: I included the files; dir1, file1, dir2, etc.
